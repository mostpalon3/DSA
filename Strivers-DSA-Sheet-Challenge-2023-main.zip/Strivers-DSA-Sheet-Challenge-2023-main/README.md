# Strivers-DSA-Sheet-Challenge-2023

### Topics Include 

- Step 1: Learn the basics
- Step 2: Important sorting algorithms
- Step 3: Solve Problems on Arrays
- Step 4: Binary Search
- Step 5: Strings (Basic + Medium)
- Step 6: Linkedlist
- Step 7: Recursion
- Step 8: Bit Manipulation
- Step 9: Stacks and Queues
- Step 10: Sliding Window and 2 pointer problems
- Step 11: Heaps
- Step 12: Greedy Algorithms
- Step 13: Binary Tree
- Step 14: Binary Search Trees
- Step 15: Graphs
- Step 16: Dynamic Programming
- Step 17: Tries
- Step 18: Strings (Hard que)

(<a href="https://takeuforward.org/strivers-a2z-dsa-course/strivers-a2z-dsa-course-sheet-2/">Strivers DSA Sheet</a>)
