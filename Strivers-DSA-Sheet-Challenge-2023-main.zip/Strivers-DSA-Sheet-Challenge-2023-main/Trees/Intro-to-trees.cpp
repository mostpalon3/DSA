class Solution {
  public:
    int countNodes(int i) {
        // your code here
        return pow(2,i-1);
    }
};
