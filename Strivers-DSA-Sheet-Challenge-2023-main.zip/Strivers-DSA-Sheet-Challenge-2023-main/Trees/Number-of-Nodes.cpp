int numberOfNodes(int N){
    // Write your code here.
    return (int)pow(2,N-1);
}
